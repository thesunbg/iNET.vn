<?php
$iNETClass = new iNETClass();

$token = $params['Token'];
$registarGlobalCode = $params['RegistarGlobalCode'];
$url = $params['Url'];
$ns1_default = $params['Ns1_default'];
$ns2_default = $params['Ns2_default'];

if (!$token) {
    return array("error" => "Password not provided. Install here Setup > Domain Registrars.");
}

if (!$registarGlobalCode) {
    return array("error" => "Registrar code has not been provided. Install here Setup > Domain Registrars.");
}

if (!$url) {
    return array("error" => "The Url Control Name API is incorrect. Install here Setup > Domain Registrars.");
}

$iNETClass->Token = $token;
$iNETClass->TestMode = $params['TestMode'] ? true : false;
$iNETClass->RegistarGlobalCode = $registarGlobalCode;
$iNETClass->Url = $url;
$iNETClass->Ns1_default = $ns1_default;
$iNETClass->Ns2_default = $ns2_default;