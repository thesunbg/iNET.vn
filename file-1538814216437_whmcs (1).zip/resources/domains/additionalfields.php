<?php
$vn_domains = ".ac.vn,.biz.vn,.com.vn,.edu.vn,.gov.vn,.health.vn,.info.vn,.int.vn,.name.vn,.net.vn,.org.vn,.pro.vn,.vn,.angiang.vn,.bacgiang.vn,.backan.vn,.baclieu.vn,.bacninh.vn,.baria-vungtau.vn,.bentre.vn,.binhdinh.vn,.binhduong.vn,.binhphuoc.vn,.binhthuan.vn,.camau.vn,.cantho.vn,.caobang.vn,.daklak.vn,.daknong.vn,.danang.vn,.dienbien.vn,.dongnai.vn,.dongthap.vn,.gialai.vn,.hagiang.vn,.haiduong.vn,.haiphong.vn,.hanam.vn,.hanoi.vn,.hatinh.vn,.haugiang.vn,.hoabinh.vn,.hungyen.vn,.khanhhoa.vn,.kiengiang.vn,.kontum.vn,.laichau.vn,.lamdong.vn,.langson.vn,.laocai.vn,.longan.vn,.namdinh.vn,.nghean.vn,.ninhbinh.vn,.ninhthuan.vn,.phutho.vn,.phuyen.vn,.quangbinh.vn,.quangnam.vn,.quangngai.vn,.quangninh.vn,.quangtri.vn,.soctrang.vn,.sonla.vn,.tayninh.vn,.thaibinh.vn,.thainguyen.vn,.thanhhoa.vn,.thanhphohochiminh.vn,.thuathienhue.vn,.tiengiang.vn,.travinh.vn,.tuyenquang.vn,.vinhlong.vn,.vinhphuc.vn,.yenbai.vn";

$additionaldomainfields_vn[] = array("Name" => "Type", "Type" => "dropdown", "Options" => "Cá nhân,Công ty", "Default" => "Cá nhân", "Required" => true, "Size" => "30", "Description" => "Hình thức",);
$additionaldomainfields_vn[] = array("Name" => "MST", "Type" => "text", "Size" => "100", "Default" => "", "Required" => false, "Description" => "Mã số thuế (đối với hình thức công ty)",);
$additionaldomainfields_vn[] = array("Name" => "CMND", "Type" => "text", "Size" => "100", "Default" => "", "Required" => false, "Description" => "9 - 12(đối với hình thức cá nhân)",);
$additionaldomainfields_vn[] = array("Name" => "Birthday", "Type" => "text", "Size" => "100", "Default" => "", "Required" => false, "Description" => "Ngày sinh (YYYY-MM-DD) (đối với hình thức cá nhân)",);
$additionaldomainfields_vn[] = array("Name" => "Gender", "Type" => "dropdown", "Options" => "Nam,Nữ", "Default" => "Nam", "Required" => false, "Description" => "Giới tính (đối với hình thức cá nhân)",);
$additionaldomainfields_vn[] = array("Name" => "Position", "Type" => "text", "Size" => "100", "Default" => "", "Required" => false, "Description" => "Chức vụ (đối với hình thức cá nhân)",);

$vn_domain_arr = explode(",", $vn_domains);
foreach ($vn_domain_arr as $ext) {
    $additionaldomainfields[$ext] = $additionaldomainfields_vn;
}