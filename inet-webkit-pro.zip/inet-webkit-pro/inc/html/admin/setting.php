<?php
$preview_cta =  plugin_dir_url('') . '/inet-webkit-pro/assets/img/CTA-button.svg';
$preview_tmdt =  plugin_dir_url('') . '/inet-webkit-pro/assets/img/tmdt.svg';
$preview_payment =  plugin_dir_url('') . '/inet-webkit-pro/assets/img/payment-info-default.svg';
$preview_wallet =  plugin_dir_url('') . '/inet-webkit-pro/assets/img/payment-setting';
$dataURL =  INET_WKP_URL . 'data/data.json';

?>
<div id="inetwkp-admin">
    <div class="card-wrap">
        <div class="card-header">
            <h4 class="card-title">Cài đặt chung</h4>
        </div>
    </div>
    <div class="card-wrap">
        <div class="card-body">
            <div class="panel-wrap">

                <div class="panel-menu">
                    <div class="panel-title">Các tiện ích</div>
                    <div class="panel-content">
                        <ul>
                            <li class="panel-menu-item active" data-id="cta" data-image="<?php echo $preview_cta; ?>">
                                <span>1. Nút mua hàng (CTA)</span>
                                <span>Điều chỉnh nội dung và các cài đặt khác của nút mua hàng.</span>
                            </li>
                            <li class="panel-menu-item" data-id="ecommerce" data-image="<?php echo $preview_tmdt; ?>">
                                <span> 2. Liên kết link với sản phẩm trên các sàn TMĐT </span>
                                <span>Cho khách hàng có bán hàng trên Shopee, Lazada, Tiki, Sendo.</span>
                            </li>
                            <li class="panel-menu-item" data-id="payment" data-image="<?php echo $preview_payment; ?>">
                                <span> 3. Tùy chỉnh thông tin thanh toán </span>
                                <span>Điều chỉnh mẫu thông tin để việc quản lý CRM hiệu quả hơn.</span>
                            </li>
                            <li class="panel-menu-item" data-id="wallet" data-image="<?php echo $preview_wallet; ?>">
                                <span> 4. Tích hợp thanh toán qua các ví điện điện tử </span>
                                <span>Sử dụng Momo, Zalo Pay, VN Pay, Shopee Pay để thanh toán đơn hàng.</span>
                            </li>
                            <li class="panel-menu-item" data-id="advance">
                                <span> 5. Tùy chỉnh nâng cao sản phẩm, đơn hàng </span>
                                <span>Chức năng nâng cao, giúp tối ưu cho cửa hàng của bạn.</span>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="panel-custom">
                    <div class="panel-title">Mô tả chi tiết</div>
                    <div class="panel-content">
                        <div class="card-loading">
                            <div class="double-loading">
                                <div class="c1"></div>
                                <div class="c2"></div>
                            </div>
                        </div>


                    </div>


                </div>
                <div class="panel-preview">
                    <div class="panel-title">Ảnh demo tính năng</div>
                    <div class="panel-content">

                        <img src="<?php echo $preview_cta; ?>" alt="" class="preview-default">
                        <div class="form-group">
                            <button class="btn btn-primary" id="updateSetting" data-url="<?php echo $dataURL; ?>">Cập nhật</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
