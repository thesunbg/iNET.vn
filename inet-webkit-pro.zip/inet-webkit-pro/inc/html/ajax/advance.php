<div class="panel-content-head">
    <h3>Tùy chỉnh nâng cao sản phẩm, đơn hàng </h3>
    <p>Chức năng nâng cao, giúp tối ưu cho cửa hàng của bạn</p>
</div>
<div class="panel-content-body">
    <div class="form-group d-flex form-group-checkbox">
        <div class="form-checkbox-text">
            <label for="" class="form-label">Tạo thông báo mua hàng</label>
            <p class="form-desc">Tính năng này sẽ <strong>tự tạo 1 thông báo mua hàng</strong> của bạn với <strong>nội dung vừa có người vừa mua sản phẩm này.</strong>Mục đích là để khách hàng quyết định mua hàng nhanh hơn.</p>
        </div>
        <label class="switch">
            <input type="checkbox" id="notify" data-key='advance' class="setting-value" value="0" <?php echo $this->checkboxChecked('advance','notify'); ?>>
            <div class="slider round">
                <!--ADDED HTML -->
                <span class="on">Bật</span>
                <span class="off">Tắt</span>
                <!--END-->
            </div>
        </label>
    </div>
   
    <div class="form-group d-flex form-group-checkbox">
        <div class="form-checkbox-text">
            <label for="" class="form-label">Xuất hóa đơn VAT</label>
            <p class="form-desc">Tính năng này sẽ <strong>thêm trường yêu cầu xuất hóa đơn VAT vào Woocommerce</strong> của bạn.</p>
        </div>
        <label class="switch">
            <input type="checkbox" id="vat" data-key='advance' class="setting-value" value="0" <?php echo $this->checkboxChecked('advance','vat'); ?>>
            <div class="slider round">
                <!--ADDED HTML -->
                <span class="on">Bật</span>
                <span class="off">Tắt</span>
                <!--END-->
            </div>
        </label>
    </div>
    <div class="form-group d-flex form-group-checkbox">
        <div class="form-checkbox-text">
            <label for="" class="form-label">Rút gọn mô tả sản phẩm</label>
            <p class="form-desc">Đôi khi mô tả sản phẩm của bạn quá dài, khiến cho quá trình xem sản phẩm khó khăn. Tính năng này sẽ cho mô tả sản phẩm của bạn gọn hơn.</p>
        </div>
        <label class="switch">
            <input type="checkbox" id="compact" data-key='advance' class="setting-value" value="0" <?php echo $this->checkboxChecked('advance','compact'); ?>>
            <div class="slider round">
                <!--ADDED HTML -->
                <span class="on">Bật</span>
                <span class="off">Tắt</span>
                <!--END-->
            </div>
        </label>
    </div>
    <div class="form-group d-flex form-group-checkbox">
        <div class="form-checkbox-text">
            <label for="" class="form-label">Thông báo đơn hàng về Telegram</label>
            <p class="form-desc">Kích hoạt chức năng này sẽ gửi thông báo đơn hàng của bạn về ứng dụng Telegram của bạn. Hướng dẫn cài đặt thông báo Telegram.</p>
        </div>
        <label class="switch">
            <input type="checkbox" id="telegram" data-key='advance' class="setting-value" value="0" <?php echo $this->checkboxChecked('advance','telegram'); ?>>
            <div class="slider round">
                <!--ADDED HTML -->
                <span class="on">Bật</span>
                <span class="off">Tắt</span>
                <!--END-->
            </div>
        </label>
    </div>
</div>
