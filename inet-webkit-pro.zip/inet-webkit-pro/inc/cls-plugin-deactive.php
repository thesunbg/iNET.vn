<?php

if ( ! defined( 'WPINC' ) ) {
    die;
}
class Plugin_Deactive {

    public static function deactive() {

    }

}
