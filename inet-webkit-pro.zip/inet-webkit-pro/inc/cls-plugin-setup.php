<?php
if (!defined('WPINC')) {
    die;
}

class INETWebKitPro
{
    protected $loader;
    protected $plugin_name;
    protected $version;
    public function __construct()
    {
        if (defined('INET_WKP_VERSON')) {
            $this->version = INET_WKP_VERSON;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'INET_WKP_Plugin';
    }
  
    public function activeAdmin() {
        $adminUrl = plugin_dir_path( __DIR__ ) . 'admin/cls-plugin-admin.php';
        require_once $adminUrl;
        $pluginAdmin = new INETWebKitProAdmin();
    }

    public function activeFrontEnd() {
        $feUrl = plugin_dir_path( __DIR__ ) . 'frontend/inet-webkit-pro-frontEnd.php';
        require_once $feUrl;
        $pluginFrontEnd = new INETWebKitProFrontEnd();
    }

    public function runPlugin() {
        $this->activeAdmin();
        $this->activeFrontEnd();
    }

    public function showErrorNotice() {
        add_action( 'admin_notices', [$this,'tmplErrrorNotice'] );
    }

    public function tmplErrrorNotice() {
        ?>
        <div class="error notice">
            <p><?php _e( 'iNET Webkit Pro yêu cầu phải cài đặt và kích hoạt <a href = "/wp-admin/plugin-install.php?s=woocommerce&tab=search&type=term">WooCommerce</a>!', 'my_plugin_textdomain' ); ?></p>
        </div>
        <?php
    }
    
    public function run()
    {
        $this->loader->run();
    }

    public function get_plugin_name()
    {
        return $this->plugin_name;
    }

    public function get_loader()
    {
        return $this->loader;
    }

    public function get_version()
    {
        return $this->version;
    }
}
