<?php
/**
 * Plugin Name: iNET Webkit Pro
 * Plugin URI:  https://wordpress.org/plugins/inet-webkit-plugin/
 * Description: The best WordPress All-in-One plugin. Powered by iNET Software Co., Ltd.
 * Version:     1.0.1
 * Author:      iNET
 * Author URI:  https://inet.vn/hosting/inet-webkit-plugin
 * Text Domain: inet-webkit-pro
 * Domain Path: /languages
 * License:     GPL2
 */

if (!defined('WPINC')) {
    die;
}

define('INET_WKP_VERSON', '1.0.1');
define('INET_WKP_FILE', __FILE__);
define('INET_WKP_ABSPATH', dirname(INET_WKP_FILE) . '/');
define('INET_WKP_URL', plugins_url('/', INET_WKP_FILE));

function inetwkp_plugin_active()
{
    require_once plugin_dir_path(__FILE__) . 'inc/cls-plugin-active.php';
    Plugin_Active::active();
}

function inetwkp_plugin_deactive()
{
    require_once plugin_dir_path(__FILE__) . 'inc/cls-plugin-deactive.php';
    Plugin_Deactive::deactive();
}

if (!function_exists('is_woocommerce_activated')) {
    function is_woocommerce_activated()
    {
        if (class_exists('woocommerce')) {
            return true;
        } else {
            return false;
        }
    }
}

require plugin_dir_path(__FILE__) . 'inc/cls-plugin-setup.php';
$pluginSetup = new INETWebKitPro();
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    $pluginSetup->runPlugin();
} else {
    $pluginSetup->showErrorNotice();
}

/*
if (class_exists('WooCommerce')) {
   $pluginSetup->runPlugin();
} else {
  $pluginSetup->showErrorNotice();
}*/

// require plugin_dir_path(__FILE__) . 'admin/cls-plugin-admin.php';
// $pluginSetup = new INETWebKitProAdmin();
