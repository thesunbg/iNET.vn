const urlCurrent = window.location.search;
const urlParams = new URLSearchParams(urlCurrent);
const currentPage = urlParams.get("page");

// if (currentPage == "plugin-options-general-settings") {
//   window.onbeforeunload = function (e) {
//     e = e || window.event;
//     // For IE and Firefox prior to version 4
//     jQuery.ajax({
//       type: "get",
//       url: inetwkp_ajax_object.ajax_url,
//       data: { action: "removeDataTempo" },
//       dataType: "json",
//       success: function (response) {
//         console.log(response);
//       },
//     });
//     if (e) {
//       e.returnValue = "Any string";
//     }
//     // For Safari
//     return "Any string";
//   };
// }
jQuery(document).ready(function () {
  const currentURL = window.location.search;
  const currentURLParams = new URLSearchParams(currentURL);
  let currentID = currentURLParams.get("id");
  currentID = currentID ? currentID : "cta";
  let url = inetwkp_ajax_object.ajax_url;
  jQuery(`.panel-menu-item[data-id=${currentID}]`).addClass("active");
  showPreviewImage(jQuery(`.panel-menu-item[data-id=${currentID}]`));
  jQuery(".panel-menu-item")
    .not(`.panel-menu-item[data-id=${currentID}]`)
    .removeClass("active");
  showHtmlPanel(url, currentID);
  jQuery(".panel-menu-item").click(function () {
    let id = jQuery(this).data("id");
    showPreviewImage(jQuery(this));
    jQuery(this).addClass("active");
    jQuery(".panel-menu-item").not(this).removeClass("active");
    showHtmlPanel(url, id);
  });
  jQuery("#updateSetting").click(function () {
    let id = jQuery(this).data("id");
    jQuery(this).text("Đang cập nhật ... ");
    jQuery.ajax({
      type: "get",
      url: url,
      data: { action: "getSettingInfo" },
      dataType: "json",
      success: function (response) {
        console.log(response);
        swal(
          "Thành công",
          "Bạn đã cập nhật cài đặt thành công",
          "success"
        ).then(function () {
          const urlCurrent = window.location.search;
          window.location.href = `${urlCurrent}&id=${id}`;
        });
      },
    });
  });
  jQuery(window).on("beforeunload", function () {
    jQuery.ajax({
      type: "get",
      url: inetwkp_ajax_object.ajax_url,
      data: { action: "removeDataTempo" },
      dataType: "json",
      success: function (response) {
        console.log(response);
      },
    });
  });
  jQuery(".upload_input_qr").each(function (i, e) {
    jQuery(e).hide();
    jQuery(e).after(
      '<div class="wp-hp-wc-preview-qrcode"><img id="placeholder_' +
        jQuery(e).attr("name") +
        '" src="' +
        jQuery(e).val() +
        '"></div>'
    );
    jQuery(e).after(
      '<input type="button" class="btn_upload_qr button button-primary button-large" data-forinput="' +
        jQuery(e).attr("name") +
        '" value="Chọn Hình">'
    );
  });
  jQuery(".btn_upload_qr").on("click", function (e) {
    e.preventDefault();
    var inputName = jQuery(this).data("forinput");
    var custom_uploader = wp
      .media({
        title: "Chọn Hình QR Code",
        button: {
          text: "Chọn",
        },
        multiple: false,
      })
      .on("select", function () {
        var attachment = custom_uploader
          .state()
          .get("selection")
          .first()
          .toJSON();
        jQuery('input[name="' + inputName + '"]').val(attachment.url);
        jQuery("#placeholder_" + inputName).attr("src", attachment.url);
      })
      .open();

    return false;
  });
});
function showHtmlPanel(url, id) {
  jQuery("#updateSetting").attr("data-id", id);
  showLoading();
  jQuery.ajax({
    type: "get",
    url: url,
    data: { action: "showHtmlPanel", id: id },
    dataType: "html",
    success: function (response) {
      jQuery(".panel-custom .panel-content").html(response);
      jQuery(".setting-value").change(function () {
        let id = jQuery(this).attr("id");
        let key = jQuery(this).data("key");
        let value = jQuery(this).val();
        let type = jQuery(this).attr("type");
        if (type == "checkbox") {
          if (this.checked) {
            value = 1;
          }
        }
        saveTemporary(key, id, value);
      });
    },
  });
}
function showPreviewImage(ele) {
  let image = ele.data("image");
  image = image
    ? image
    : "https://license.mauwp.net/wp-content/plugins/inet-webkit-pro/assets/img/placeholder-image.jpg";
  jQuery(".preview-default").attr("src", image);
}
const saveTemporary = (id = "", key = "", value = "") => {
  jQuery.ajax({
    type: "get",
    url: inetwkp_ajax_object.ajax_url,
    data: { action: "saveTempo", id: id, key: key, value: value },
    dataType: "json",
    success: function (response) {
      console.log(response);
    },
  });
};
function showLoading() {
  let loading = ` <div class="card-loading">
    <div class="double-loading">
        <div class="c1"></div>
        <div class="c2"></div>
    </div>
    </div>`;
  jQuery(".panel-custom .panel-content").html(loading);
  jQuery(".card-loading").css("display", "flex");
}
