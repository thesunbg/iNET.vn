<?php
class INETWebKitProAdmin
{
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'admin_style']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        $this->active_ajax();

        // Media
        add_action('admin_enqueue_scripts', [$this, 'load_media_files']);

        // Ecommerce
        add_action('woocommerce_product_options_general_product_data', [$this, 'activeEcommerceSetting']);
        add_action('woocommerce_process_product_meta', [$this, 'saveEcommercefields']);

        // Wallet
        add_filter('woocommerce_payment_gateways', [$this, 'activeWalletSetting']);
        // add_action( 'plugins_loaded', [$this,'initWalletClass'] );

        // VAT
        add_action('woocommerce_admin_order_data_after_shipping_address', [$this, 'inetwkp_hpwc_after_shipping_address_vat'], 99);
    }

    public function admin_style()
    {
        wp_enqueue_style('fontawesome-styles', 'https://pro.fontawesome.com/releases/v5.10.0/css/all.css',);
        wp_enqueue_style('admin-styles', INET_WKP_URL . 'assets/admin/css/admin.css',);
        wp_enqueue_style('star-rating-styles', INET_WKP_URL . 'assets/admin/survey/star-rating-svg.css',);
        wp_enqueue_style('survey-styles', INET_WKP_URL . 'assets/admin/survey/style.css',);
        wp_enqueue_script('custom-js', INET_WKP_URL . 'assets/admin/js/main.js', array(), time(), true);
        wp_localize_script('custom-js', 'inetwkp_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));

        // Survey
        wp_enqueue_script('sweet-js', 'https://unpkg.com/sweetalert/dist/sweetalert.min.js', array(), time(), true);
        wp_enqueue_script('star-rating-js', INET_WKP_URL . 'assets/admin/survey/jquery.star-rating-svg.js', array(), time(), true);
        wp_enqueue_script('survey-js', INET_WKP_URL . 'assets/admin/survey/survey.js', array(), time(), true);
    }

    public function add_admin_menu()
    {
        add_menu_page(
            'iNET Webkit',
            'iNET Webkit <span class = "menu-admin-icon">Pro</span>',
            'manage_options',
            'inetwkp-plugin',
            [$this, 'show_general_setting_page'],
            '',
            '2'
        );
        // add_submenu_page('inetwkp-plugin', 'Cài đặt chung', 'Cài đặt chung', 'manage_options', 'plugin-options-general-settings', [$this, 'show_general_setting_page']);
    }

    public function show_html_admin()
    {
        require_once plugin_dir_path(__FILE__) . '/html/page/index.php';
    }

    public function show_general_setting_page()
    {
        require_once plugin_dir_path(__FILE__) . '/html/page/setting.php';
    }

    public function active_ajax()
    {
        add_action('wp_ajax_showHtmlPanel', [$this, 'showHtmlPanel_func']);
        add_action('wp_ajax_nopriv_showHtmlPanel', [$this, 'showHtmlPanel_func']);

        // Setting Info
        add_action('wp_ajax_getSettingInfo', [$this, 'getSettingInfo_func']);
        add_action('wp_ajax_nopriv_getSettingInfo', [$this, 'getSettingInfo_func']);

        // Save Tempo
        add_action('wp_ajax_saveTempo', [$this, 'saveTempo_func']);
        add_action('wp_ajax_nopriv_saveTempo', [$this, 'saveTempo_func']);

        // Remove Tempo
        add_action('wp_ajax_removeDataTempo', [$this, 'removeDataTempo_func']);
        add_action('wp_ajax_nopriv_removeDataTempo', [$this, 'removeDataTempo_func']);

        // Compare Data
        add_action('wp_ajax_compareData', [$this, 'compareData_func']);
        add_action('wp_ajax_nopriv_compareData', [$this, 'compareData_func']);

        // Survey
        add_action('wp_ajax_surveySubmit', [$this, 'surveySubmit_func']);
        add_action('wp_ajax_nopriv_surveySubmit', [$this, 'surveySubmit_func']);
    }

    public function getDataInfo($dataURL)
    {
        $result = file_get_contents($dataURL);
        $result = json_decode($result, true);
        return $result;
    }

    public function showHtmlPanel_func()
    {
        $id = $_GET['id'];
        $fileName = $id . ".php";
        $fileUrl = plugin_dir_path(__FILE__) . "/html/ajax/{$fileName}";
        $fileDefault = plugin_dir_path(__FILE__) . "/html/ajax/cta.php";
        $fileUrl = (file_exists($fileUrl)) ? $fileUrl : $fileDefault;
        $dataURL =  plugin_dir_path(__FILE__) . '/data/data.json';
        $data = file_get_contents($dataURL);
        $data = json_decode($data, true);
        $dataTempoURL =  plugin_dir_path(__FILE__) . '/data/dataTempo.json';
        $dataTempo = $this->getDataInfo($dataTempoURL);
        require_once  $fileUrl;
        die();
    }

    public function checkboxChecked($keyPage = "", $keySetting = "")
    {
        $dataTempoURL =  plugin_dir_path(__FILE__) . '/data/dataTempo.json';
        $dataTempo = $this->getDataInfo($dataTempoURL);
        $dataURL =  plugin_dir_path(__FILE__) . '/data/data.json';
        $data = $this->getDataInfo($dataURL);
        $value = (isset($dataTempo[$keyPage][$keySetting])) ? $dataTempo[$keyPage][$keySetting] : $data[$keyPage][$keySetting];
        $valueChecked = (!empty($value) && $value == '1') ? "checked" : "";
        return $valueChecked;
    }

    public function getSettingInfo_func()
    {
        // Lưu Data tempo vào data
        $dataTempoURL =  plugin_dir_path(__FILE__) . '/data/dataTempo.json';
        $dataTempo = $this->getDataInfo($dataTempoURL);
        $dataURL =  plugin_dir_path(__FILE__) . '/data/data.json';
        $data = $this->getDataInfo($dataURL);
        foreach ($data as $key => $settings) {
            foreach ($settings as  $setting => $value) {
                $data[$key][$setting] = (isset($dataTempo[$key][$setting])) ? $dataTempo[$key][$setting] : $value;
            }
        }
        file_put_contents($dataTempoURL, json_encode([]));
        file_put_contents($dataURL, json_encode($data));
        $result = [
            'data' => $data,
            'dataTempo' => $dataTempo,
        ];
        echo wp_json_encode($result);
        die();
    }

    public function removeDataTempo_func()
    {
        $dataTempoURL =  plugin_dir_path(__FILE__) . '/data/dataTempo.json';
        $data = [];
        $dataUpdate = json_encode($data);
        file_put_contents($dataTempoURL, $dataUpdate);
    }

    public function saveTempo_func()
    {
        $dataTempoURL = plugin_dir_path(__FILE__) . '/data/dataTempo.json';
        $dataTempo = file_get_contents($dataTempoURL);
        $dataTempo = json_decode($dataTempo, true);
        $id = isset($_GET['id']) ? $_GET['id'] : "";
        $key = isset($_GET['key']) ? $_GET['key'] : "";
        $value = isset($_GET['value']) ? $_GET['value'] : "";
        $dataTempo[$id][$key] = $value;
        $dataTempoUpdate = json_encode($dataTempo);
        file_put_contents($dataTempoURL, $dataTempoUpdate);
        echo wp_json_encode($dataTempo);
        die();

    }

    public function activeEcommerceSetting()
    {
        $dataURL = plugin_dir_path(__FILE__) . '/data/data.json';
        $data = $this->getDataInfo($dataURL);
        foreach ($data['ecommerce'] as $key => $item) {
            $title = ucfirst($key);
            if ($item == '1') {
                ?>
                <style type="text/css">
                    .general_options .general_tab {
                        display: block;
                    }
                </style>
                <?php
                woocommerce_wp_text_input(
                    array(
                        'id' => "product-ecommerce-{$key}",
                        'placeholder' => __("Nhập link sản phẩm sàn {$title}", 'wphp-wc'),
                        'label' => __("Link {$title}", 'wphp-wc')
                    )
                );
            }
        }
    }
    public function saveEcommercefields()
    {
        global $post;
        $postID = $post->ID;
        $dataURL =  plugin_dir_path(__FILE__) . '/data/data.json';
        $data = $this->getDataInfo($dataURL);
        foreach ($data['ecommerce'] as $key => $item) {
            $name = "product-ecommerce-{$key}";
            $value = $_POST[$name];
            if ($value) {
                update_post_meta($postID, $name, esc_attr($value));
            }
        }
    }

    public function activeWalletSetting($gateways)
    {
        $dataURL =  plugin_dir_path(__FILE__) . '/data/data.json';
        $data = $this->getDataInfo($dataURL);
        foreach ($data['wallet'] as $key => $item) {
            if ($item == '1') {
                $name =  "INET_WKP_Wallet_" . ucfirst($key);
                $gateways[] = $name;
                $fileURL = plugin_dir_path(__FILE__) . "wallet/{$name}.php";
                if (file_exists($fileURL)) {
                    require_once $fileURL;
                }
            }
        }
        require_once plugin_dir_path(__FILE__) . 'wallet/INET_WKP_Wallet_Momo.php';
        return $gateways;
    }

    public function load_media_files()
    {
        wp_enqueue_media();
    }
    function inetwkp_hpwc_after_shipping_address_vat($order)
    {
        $inetwkp_hpwc_invoice_vat_input = get_post_meta($order->get_id(), 'inetwkp_hpwc_invoice_vat_input', true);
        $billing_vat_company = get_post_meta($order->get_id(), 'billing_vat_company', true);
        $billing_vat_tax_code = get_post_meta($order->get_id(), 'billing_vat_tax_code', true);
        $billing_vat_company_address = get_post_meta($order->get_id(), 'billing_vat_company_address', true);
?>
        <p><strong>Xuất hóa đơn:</strong> <?php echo ($inetwkp_hpwc_invoice_vat_input) ? 'Có' : 'Không'; ?></p>
        <?php
        if ($inetwkp_hpwc_invoice_vat_input) :
        ?>
            <p>
                <strong>Thông tin xuất hóa đơn:</strong><br>
                Tên công ty: <?php echo $billing_vat_company; ?><br>
                Mã số thuế: <?php echo $billing_vat_tax_code; ?><br>
                Địa chỉ: <?php echo $billing_vat_company_address; ?><br>
            </p>
<?php
        endif;
    }
    public function surveySubmit_func()
    {
        $tool_name = "iNET Webkit Pro";
        $params = $_GET;
        $host_name = gethostname();
        $data_post = [
            'name' => "Đánh giá {$tool_name}",
            'is_easy' => $params['valueSurvey'],
            'star' => $params['starSurvey'],
            'comment' => $params['comment'],
            'host_name' => $host_name,
        ];

        $url = "https://mauwp.net/rating-product";
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => json_encode($data_post),
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json"
            ],
        ]);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            $status = 400;
            $msg = $err;
        } else {
            $response = json_decode($response, true);
            if ($response['status'] == 400) {
                $status  = 400;
                $msg =  implode(",", $response['msg']);
            } else {
                $status = 200;
                $msg = "<p class = 'text-success text-center'>Cảm ơn bạn đã góp ý</p>";
            }
        }
        $result = [
            'params' => $params,
            'status' => $status,
            'msg' => $msg,
            'response' => $response,
        ];
        echo wp_json_encode($result);
       
        die();
    }
}
