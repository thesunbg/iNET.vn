<div id="inetwkp-admin">
    <div class="card-wrap">
        <div class="card-header d-flex ">
            <div class="card-header-text">
                <h1 class="card-title">Chào mừng bạn đến với iNET Webkit Pro</h1>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Facilis maiores obcaecati porro mollitia quos eveniet quidem pariatur at est cupiditate fugit delectus saepe nesciunt accusamus omnis ipsam quod, laborum consequatur!</p>
            </div>
            <div class="card-header-logo">
                <?php
                $logo_url = INET_WKP_URL . 'assets/admin/img/inetwkp.png';

                ?>
                <img src="<?php echo $logo_url; ?>" alt="">
            </div>

        </div>
    </div>
    <div class="card-wrap card-active">
        <div class="card-header">
            <h4 class="card-title">Kích hoạt Plugin</h4>
        </div>
        <div class="card-body">
            <input type="text" class="form-control" placeholder="Purchase code (e.g. 123e4567-e89b-12d3-a456-426614174000)">
            <button class="btn btn-primary">Kích hoạt</button>
        </div>
    </div>

</div>
