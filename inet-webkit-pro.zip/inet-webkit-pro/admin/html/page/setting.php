<?php
$preview_cta =  INET_WKP_URL . 'assets/admin/img/CTA-button.svg';
$preview_tmdt =  INET_WKP_URL . 'assets/admin/img/tmdt.svg';
$preview_payment =  INET_WKP_URL . 'assets/admin/img/payment-info-default.svg';
$preview_wallet =  INET_WKP_URL. 'assets/admin/img/payment-setting';
$dataURL =  INET_WKP_URL . 'data/data.json';
$tool_name = "iNET Webkit Pro";
?>
<div id="inetwkp-admin">
    <div class="card-wrap">
        <div class="card-header">
            <h4 class="card-title">Cài đặt chung</h4>
        </div>
    </div>
    <div class="card-wrap">
        <div class="card-body">
            <div class="panel-wrap">

                <div class="panel-menu">
                    <div class="panel-title">Các tiện ích</div>
                    <div class="panel-content">
                        <ul>
                            <li class="panel-menu-item active" data-id="cta" data-image="<?php echo $preview_cta; ?>">
                                <span>1. Nút mua hàng (CTA)</span>
                                <span>Điều chỉnh nội dung và các cài đặt khác của nút mua hàng.</span>
                            </li>
                            <li class="panel-menu-item" data-id="ecommerce" data-image="<?php echo $preview_tmdt; ?>">
                                <span> 2. Liên kết link với sản phẩm trên các sàn TMĐT </span>
                                <span>Cho khách hàng có bán hàng trên Shopee, Tiktok, Lazada, Tiki, Sendo.</span>
                            </li>
                            <li class="panel-menu-item" data-id="payment" data-image="<?php echo $preview_payment; ?>">
                                <span> 3. Tùy chỉnh thông tin thanh toán </span>
                                <span>Điều chỉnh mẫu thông tin để việc quản lý CRM hiệu quả hơn.</span>
                            </li>
                            <li class="panel-menu-item" data-id="wallet" data-image="<?php echo $preview_wallet; ?>">
                                <span> 4. Tích hợp thanh toán qua các ví điện điện tử </span>
                                <span>Sử dụng Momo, Zalo Pay, VN Pay, Shopee Pay để thanh toán đơn hàng.</span>
                            </li>
                            <li class="panel-menu-item" data-id="advance">
                                <span> 5. Tùy chỉnh nâng cao sản phẩm, đơn hàng </span>
                                <span>Chức năng nâng cao, giúp tối ưu cho cửa hàng của bạn.</span>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="panel-custom">
                    <div class="panel-title">Mô tả chi tiết</div>
                    <div class="panel-content">
                        <div class="card-loading">
                            <div class="double-loading">
                                <div class="c1"></div>
                                <div class="c2"></div>
                            </div>
                        </div>


                    </div>


                </div>
                <div class="panel-preview">
                    <div class="panel-title">Ảnh demo tính năng</div>
                    <div class="panel-content">

                        <img src="<?php echo $preview_cta; ?>" alt="" class="preview-default">
                        <div class="form-group">
                            <button class="btn btn-primary" id="updateSetting" data-url="<?php echo $dataURL; ?>">Cập nhật</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="survey">
    <button class="survey-toggle"><i class="fa fa-angle-up"></i></button>
    <div class="survey-inner">
        <div class="survey-head">
            <h3>Đánh giá <?php echo $tool_name; ?></h3>
        </div>
        <div class="survey-body">
            <p class="survey-body-title">Bạn cảm nhận công cụ <?php echo $tool_name; ?> như thế nào?</p>
            <div class="survey-form">
                <div class="form-group">
                    <input type="radio" name="survey_1" class="radio-input" value="1" id="survey_1_yes">
                    <label for="survey_1_yes" class="radio-label"></label>
                    <label for="survey_1_yes">Dễ sử dụng</label>
                </div>
                <div class="form-group">
                    <input type="radio" name="survey_1" class="radio-input" value="0" id="survey_1_no">
                    <label for="survey_1_no" class="radio-label"></label>
                    <label for="survey_1_no">Không dễ sử dụng</label>
                </div>
            </div>
            <fieldset class="star-rating">
                <div class="star-rating__stars">
                    <input class="star-rating__input" type="radio" name="rating" value="1" id="rating-1" />
                    <label class="star-rating__label" for="rating-1" aria-label="One"></label>
                    <input class="star-rating__input" type="radio" name="rating" value="2" id="rating-2" />
                    <label class="star-rating__label" for="rating-2" aria-label="Two"></label>
                    <input class="star-rating__input" type="radio" name="rating" value="3" id="rating-3" />
                    <label class="star-rating__label" for="rating-3" aria-label="Three"></label>
                    <input class="star-rating__input" type="radio" name="rating" value="4" id="rating-4" />
                    <label class="star-rating__label" for="rating-4" aria-label="Four"></label>
                    <input class="star-rating__input" type="radio" name="rating" value="5" id="rating-5" />
                    <label class="star-rating__label" for="rating-5" aria-label="Five"></label>
                    <div class="star-rating__focus"></div>
                </div>
            </fieldset>
            <div class="form-group rating-textarea">
               
                <textarea class="form-control" rows="4" id="comment" placeholder="Hãy để lại nhận xét và cùng iNET trải nghiệm những giá trị mà chúng tôi sẽ mang đến cho bạn tại công cụ này."></textarea>
            </div>
            <div class="form-group text-right">
                <button class="btn btn-primary" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Đang xử lý" disabled id="surveySubmit" data-url = "#">Đánh giá</button>
            </div>
        </div>
    </div>
</div>
